import { Head, Link, usePage } from '@inertiajs/react';
import {
    ArrowRight,
    Flag,
    MessageCircle,
    ShieldCheck,
    ShoppingBag,
    Star,
    Tag,
    Users,
} from 'lucide-react';
import {
    type CSSProperties,
    type ElementType,
    type ReactNode,
    useEffect,
    useRef,
} from 'react';
import SiteImage from '../components/ui/SiteImage';
import { logo, siteImages } from '../config/siteImages';
import type { SharedProps } from '../types/shared';

const gold =
    'inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-sun-400 px-6 font-display text-[15px] font-bold text-pine-950 shadow-lg shadow-sun-500/30 transition duration-300 hover:-translate-y-0.5 hover:bg-sun-500';
const outlineOnLight =
    'inline-flex h-12 items-center justify-center gap-2 rounded-xl border-2 border-pine-900/25 px-6 font-display text-[15px] font-bold text-pine-900 transition duration-300 hover:-translate-y-0.5 hover:border-pine-900 hover:bg-white';

const headline = 'Buy, sell and trade right on campus.'.split(' ');
const swapWords = ['textbooks', 'uniforms', 'gadgets', 'snacks', 'tutoring'];
const ticker = ['Textbooks', 'Uniforms', 'Gadgets', 'Snacks', 'Tutoring', 'Printing', 'Dorm essentials', 'Notebooks'];

const categories = [
    { name: 'Electronics', note: 'Phones, laptops, calculators and accessories', image: siteImages.categories.electronics, className: 'col-span-2 row-span-2 min-h-[300px]' },
    { name: 'Clothing', note: 'Uniforms, shoes and bags', image: siteImages.categories.clothing, className: 'min-h-[150px]' },
    { name: 'School Supplies', note: 'Books, notebooks and tools', image: siteImages.categories.schoolSupplies, className: 'min-h-[150px]' },
    { name: 'Food & Drinks', note: 'Snacks and homemade treats', image: siteImages.categories.food, className: 'min-h-[150px]' },
    { name: 'Home & Living', note: 'Dorm and room essentials', image: siteImages.categories.home, className: 'min-h-[150px]' },
    { name: 'Services', note: 'Tutoring, printing, repairs and more', image: siteImages.categories.services, className: 'col-span-2 min-h-[150px]' },
];

const steps = [
    { title: 'List what you have', text: 'Add photos, a price and a short description. Choose whether it is an item or a service.' },
    { title: 'Chat and agree on a meet-up', text: 'Buyers message you inside the app. Pick a safe spot on campus and a time that works.' },
    { title: 'Hand over and get rated', text: 'Mark the order complete. The buyer leaves a review that appears on your profile.' },
];

const trust = [
    { icon: Star, title: 'Reviews you can rely on', text: 'Only buyers with a completed order can rate a seller.' },
    { icon: MessageCircle, title: 'Chat inside the app', text: 'Talk to buyers and sellers without sharing your phone number.' },
    { icon: Flag, title: 'Report in a few taps', text: 'Scams, spam and prohibited items go straight to the admins.' },
    { icon: ShieldCheck, title: 'Admins keep watch', text: 'Listings can be hidden and accounts suspended when rules are broken.' },
];

const offsets = { left: ['-56px', '0px'], right: ['56px', '0px'], up: ['0px', '40px'] } as const;

/** Slides its content in from a side the first time it scrolls into view. */
function Reveal({
    as: Tag = 'div',
    from = 'up',
    delay = 0,
    base = 'site-reveal',
    className = '',
    children,
}: {
    as?: ElementType;
    from?: keyof typeof offsets;
    delay?: number;
    base?: string;
    className?: string;
    children?: ReactNode;
}) {
    const ref = useRef<HTMLElement>(null);

    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        if (!('IntersectionObserver' in window)) {
            el.classList.add('is-in');
            return;
        }
        const io = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    el.classList.add('is-in');
                    io.disconnect();
                }
            },
            { threshold: 0.2 },
        );
        io.observe(el);
        return () => io.disconnect();
    }, []);

    const [rx, ry] = offsets[from];

    return (
        <Tag
            ref={ref}
            className={`${base} ${className}`}
            style={{ '--rx': rx, '--ry': ry, '--d': `${delay}ms` } as CSSProperties}
        >
            {children}
        </Tag>
    );
}

function Brand({ light = false }: { light?: boolean }) {
    return (
        <Link href="/" className="group flex items-center gap-3">
            <img
                src={`/images/${logo}`}
                alt=""
                className="h-11 w-11 rounded-full bg-white shadow-sm transition duration-500 group-hover:rotate-[360deg]"
            />
            <span className={`font-display text-xl font-extrabold ${light ? 'text-white' : 'text-pine-900'}`}>
                ACC Marketplace
            </span>
        </Link>
    );
}

export default function Home() {
    const { auth } = usePage<SharedProps>().props;
    const user = auth.user;
    const bar = useRef<HTMLDivElement>(null);
    const head = useRef<HTMLElement>(null);

    // Scroll progress bar + header turning solid. Writes straight to the DOM, no re-renders.
    useEffect(() => {
        const onScroll = () => {
            const max = document.documentElement.scrollHeight - window.innerHeight;
            if (bar.current) bar.current.style.transform = `scaleX(${max > 0 ? window.scrollY / max : 0})`;
            if (head.current) head.current.dataset.stuck = String(window.scrollY > 12);
        };
        onScroll();
        window.addEventListener('scroll', onScroll, { passive: true });
        return () => window.removeEventListener('scroll', onScroll);
    }, []);

    return (
        <div className="site overflow-x-clip bg-white font-body text-pine-950">
            <Head title="Buy, sell and trade on campus">
                <meta
                    name="description"
                    content="ACC Marketplace is where Abuyog Community College students buy, sell and trade items and services on campus."
                />
            </Head>

            <a
                href="#main"
                className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:font-semibold"
            >
                Skip to content
            </a>

            <div
                ref={bar}
                aria-hidden="true"
                style={{ transform: 'scaleX(0)' }}
                className="fixed inset-x-0 top-0 z-[60] h-[3px] origin-left bg-gradient-to-r from-pine-600 via-sprout-500 to-sun-400"
            />

            {/* Navigation */}
            <header
                ref={head}
                data-stuck="false"
                className="sticky top-0 z-50 border-b border-transparent transition-all duration-300 data-[stuck=true]:border-pine-900/10 data-[stuck=true]:bg-white/85 data-[stuck=true]:shadow-sm data-[stuck=true]:backdrop-blur-md"
            >
                <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between gap-6 px-5 sm:px-8">
                    <Brand />

                    <nav className="hidden items-center gap-8 text-[15px] font-medium text-pine-900/75 md:flex" aria-label="Sections">
                        {[['#how', 'How it works'], ['#categories', 'Categories'], ['#trust', 'Safety']].map(([href, label]) => (
                            <a
                                key={href}
                                href={href}
                                className="relative py-1 transition hover:text-pine-700 after:absolute after:inset-x-0 after:-bottom-0.5 after:h-0.5 after:origin-left after:scale-x-0 after:rounded after:bg-sun-400 after:transition-transform after:duration-300 hover:after:scale-x-100"
                            >
                                {label}
                            </a>
                        ))}
                    </nav>

                    <div className="flex items-center gap-2 sm:gap-3">
                        {user ? (
                            <Link href="/dashboard" className="inline-flex h-10 items-center rounded-lg bg-pine-800 px-5 font-display text-sm font-bold text-white transition hover:bg-pine-900">
                                Go to dashboard
                            </Link>
                        ) : (
                            <>
                                <Link href="/login" className="inline-flex h-10 items-center rounded-lg px-4 font-display text-sm font-bold text-pine-900 transition hover:bg-mist-100">
                                    Log in
                                </Link>
                                <Link href="/register" className="inline-flex h-10 items-center rounded-lg bg-sun-400 px-4 font-display text-sm font-bold text-pine-950 transition hover:bg-sun-500 sm:px-5">
                                    Create account
                                </Link>
                            </>
                        )}
                    </div>
                </div>
            </header>

            <main id="main">
                {/* Hero */}
                <section className="relative -mt-[72px] overflow-hidden bg-gradient-to-b from-mist-100 via-mist-50 to-white pt-[72px]">
                    <div aria-hidden="true" className="site-drift pointer-events-none absolute -left-24 top-16 h-96 w-96 rounded-full bg-sprout-300/40 blur-3xl" />
                    <div aria-hidden="true" className="site-drift pointer-events-none absolute -right-24 bottom-0 h-[26rem] w-[26rem] rounded-full bg-sun-300/50 blur-3xl [animation-delay:-9s]" />

                    <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 pb-20 pt-12 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:pb-28 lg:pt-20">
                        <div>
                            <h1 aria-label="Buy, sell and trade right on campus." className="font-display text-[2.75rem] font-extrabold leading-[1.04] text-pine-950 sm:text-6xl lg:text-[4.25rem]">
                                {headline.map((word, i) => (
                                    <span key={i} aria-hidden="true" className="inline-block overflow-hidden pb-[0.1em] align-bottom">
                                        <span className="site-word inline-block" style={{ animationDelay: `${150 + i * 90}ms` }}>
                                            {word}&nbsp;
                                        </span>
                                    </span>
                                ))}
                            </h1>

                            <p className="site-rise site-rise-2 mt-6 flex items-center gap-2 font-display text-xl font-bold text-pine-700">
                                <span className="font-body font-medium text-pine-900/70">Today on campus:</span>
                                <span className="block h-[1.6em] overflow-hidden" aria-hidden="true">
                                    <span className="site-swap block">
                                        {[...swapWords, swapWords[0]].map((w, i) => (
                                            <span key={i} className="block h-[1.6em] leading-[1.6em]">{w}</span>
                                        ))}
                                    </span>
                                </span>
                            </p>

                            <p className="site-rise site-rise-3 mt-4 max-w-xl text-lg leading-relaxed text-pine-900/75">
                                Textbooks, uniforms, gadgets, snacks and services, listed by Abuyog Community College students and handed over between classes.
                            </p>

                            <div className="site-rise site-rise-4 mt-9 flex flex-wrap gap-3">
                                {user ? (
                                    <Link href="/marketplace" className={gold}>
                                        <ShoppingBag size={18} />
                                        Open the marketplace
                                    </Link>
                                ) : (
                                    <>
                                        <Link href="/register" className={`${gold} group`}>
                                            Create free account
                                            <ArrowRight size={18} className="transition-transform duration-300 group-hover:translate-x-1" />
                                        </Link>
                                        <Link href="/marketplace" className={outlineOnLight}>
                                            Browse listings
                                        </Link>
                                    </>
                                )}
                            </div>

                            <ul className="site-rise site-rise-4 mt-10 flex flex-wrap gap-x-7 gap-y-3 text-sm font-medium text-pine-900/75">
                                {[[Tag, 'Free to list'], [Users, 'Only ACC students'], [Star, 'Rated sellers']].map(([Icon, label]) => {
                                    const I = Icon as typeof Tag;
                                    return (
                                        <li key={label as string} className="flex items-center gap-2">
                                            <I size={17} className="text-sun-600" />
                                            {label as string}
                                        </li>
                                    );
                                })}
                            </ul>
                        </div>

                        {/* Arch photo */}
                        <div className="site-rise site-rise-2 relative mx-auto w-full max-w-[420px] pb-8 lg:mx-0 lg:ml-auto">
                            <div aria-hidden="true" className="absolute -right-10 top-10 h-72 w-72 rounded-full bg-sun-300/60 sm:h-96 sm:w-96" />
                            <div aria-hidden="true" className="absolute -right-4 top-4 aspect-[4/5] w-full rounded-t-[999px] rounded-b-[2rem] border-2 border-sun-400" />

                            <SiteImage
                                name={siteImages.hero}
                                alt="Abuyog Community College campus"
                                eager
                                className="aspect-[4/5] rounded-t-[999px] rounded-b-[2rem] shadow-2xl shadow-pine-950/25"
                                imageClassName="object-[66%_45%]"
                            />

                            <div className="site-float absolute -left-3 bottom-0 rounded-full bg-white p-1.5 shadow-xl [animation-delay:-2s] sm:-left-8">
                                <img src={`/images/${logo}`} alt="ACC Marketplace" className="h-24 w-24 rounded-full sm:h-28 sm:w-28" />
                            </div>

                            <div className="site-float absolute -right-2 bottom-16 w-44 rounded-2xl bg-white p-2 shadow-xl sm:-right-8 sm:w-52">
                                <SiteImage name={siteImages.heroListing} alt="Example listing: scientific calculator" className="aspect-[4/3] rounded-xl" />
                                <div className="px-1.5 pb-1 pt-2.5">
                                    <p className="truncate text-sm font-semibold text-pine-950">Scientific calculator</p>
                                    <div className="mt-1 flex items-center justify-between">
                                        <span className="font-display text-base font-extrabold text-pine-900">₱350</span>
                                        <span className="rounded-full bg-mist-100 px-2 py-0.5 text-xs font-semibold text-pine-700">Available</span>
                                    </div>
                                    <p className="mt-1.5 text-[11px] text-pine-900/50">Example listing</p>
                                </div>
                            </div>

                            <div className="site-float absolute -left-2 top-24 flex items-center gap-2 rounded-2xl rounded-bl-sm bg-pine-800 px-3.5 py-2.5 text-sm font-medium text-white shadow-xl [animation-delay:-4s] sm:-left-10">
                                <MessageCircle size={16} className="text-sun-400" />
                                Is this still available?
                            </div>
                        </div>
                    </div>
                </section>

                {/* Sliding ticker */}
                <div className="overflow-hidden bg-sun-400 py-3.5 text-pine-950" aria-hidden="true">
                    <div className="site-marquee flex w-max items-center">
                        {[...ticker, ...ticker].map((item, i) => (
                            <span key={i} className="flex items-center font-display text-lg font-bold">
                                <span className="px-6">{item}</span>
                                <Star size={14} className="fill-pine-800 text-pine-800" />
                            </span>
                        ))}
                    </div>
                </div>

                {/* Categories */}
                <section id="categories" className="scroll-mt-20 bg-white py-20 lg:py-28">
                    <div className="mx-auto max-w-7xl px-5 sm:px-8">
                        <Reveal from="left" className="max-w-2xl">
                            <h2 className="font-display text-4xl font-extrabold leading-tight text-pine-950 sm:text-5xl">
                                Find what you need between classes
                            </h2>
                            <p className="mt-4 text-lg leading-relaxed text-pine-900/70">
                                Everything is posted by students on the same campus, so pick-up is a short walk away.
                            </p>
                        </Reveal>

                        <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
                            {categories.map((category, i) => (
                                <Reveal key={category.name} from={i % 2 ? 'right' : 'left'} delay={(i % 3) * 90} className={`flex ${category.className}`}>
                                    <Link
                                        href={`/marketplace?q=${encodeURIComponent(category.name)}`}
                                        className="group relative isolate flex flex-1 items-end overflow-hidden rounded-2xl"
                                    >
                                        <SiteImage
                                            name={category.image}
                                            alt={category.name}
                                            className="absolute inset-0 -z-10"
                                            imageClassName="transition duration-700 group-hover:scale-110"
                                        />
                                        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-pine-950/90 via-pine-950/35 to-transparent transition-opacity duration-500 group-hover:from-pine-950/95" />
                                        <span className="absolute right-4 top-4 grid h-10 w-10 -translate-x-4 place-items-center rounded-full bg-sun-400 text-pine-950 opacity-0 transition duration-300 group-hover:translate-x-0 group-hover:opacity-100">
                                            <ArrowRight size={18} />
                                        </span>
                                        <div className="p-5 transition-transform duration-300 group-hover:-translate-y-1">
                                            <h3 className="font-display text-xl font-bold text-white sm:text-2xl">{category.name}</h3>
                                            <p className="mt-1 text-sm leading-snug text-white/80">{category.note}</p>
                                        </div>
                                    </Link>
                                </Reveal>
                            ))}

                            <Reveal from="right" delay={180} className="col-span-2 flex min-h-[150px]">
                                <Link
                                    href="/marketplace"
                                    className="site-shimmer group flex flex-1 flex-col justify-between rounded-2xl bg-sun-400 p-5 text-pine-950 transition hover:bg-sun-500"
                                >
                                    <ShoppingBag size={28} className="transition-transform duration-300 group-hover:-rotate-12" />
                                    <div>
                                        <h3 className="font-display text-xl font-bold sm:text-2xl">Browse everything</h3>
                                        <p className="mt-1 flex items-center gap-1.5 text-sm font-medium">
                                            See all listings
                                            <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-1.5" />
                                        </p>
                                    </div>
                                </Link>
                            </Reveal>
                        </div>
                    </div>
                </section>

                {/* How it works */}
                <section id="how" className="scroll-mt-20 bg-mist-50 py-20 lg:py-28">
                    <div className="mx-auto max-w-7xl px-5 sm:px-8">
                        <Reveal from="left">
                            <h2 className="max-w-2xl font-display text-4xl font-extrabold leading-tight text-pine-950 sm:text-5xl">
                                Selling takes three steps
                            </h2>
                        </Reveal>

                        <ol className="relative mt-14 grid gap-6 md:grid-cols-3">
                            <Reveal base="site-draw" className="absolute left-[16%] right-[16%] top-[3.6rem] hidden h-0.5 bg-gradient-to-r from-pine-600 to-sun-400 md:block" />
                            {steps.map((step, index) => (
                                <Reveal as="li" key={step.title} from={['left', 'up', 'right'][index] as 'left'} delay={index * 120} className="relative">
                                    <div className="h-full rounded-2xl border-t-[6px] border-sun-400 bg-white p-7 shadow-sm transition duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-pine-900/10">
                                        <span className="grid h-14 w-14 place-items-center rounded-full bg-pine-800 font-display text-2xl font-extrabold text-sun-400 ring-8 ring-mist-50">
                                            {index + 1}
                                        </span>
                                        <h3 className="mt-5 font-display text-xl font-bold text-pine-950">{step.title}</h3>
                                        <p className="mt-2 leading-relaxed text-pine-900/70">{step.text}</p>
                                    </div>
                                </Reveal>
                            ))}
                        </ol>
                    </div>
                </section>

                {/* Trust & safety */}
                <section id="trust" className="relative scroll-mt-20 overflow-hidden bg-pine-900 py-20 text-white lg:py-28">
                    <div aria-hidden="true" className="site-drift pointer-events-none absolute -left-32 top-0 h-96 w-96 rounded-full bg-pine-600/40 blur-3xl" />
                    <div aria-hidden="true" className="site-drift pointer-events-none absolute -bottom-24 right-0 h-80 w-80 rounded-full bg-sun-400/15 blur-3xl [animation-delay:-8s]" />

                    <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-[1.1fr_0.9fr]">
                        <div>
                            <Reveal from="left">
                                <h2 className="max-w-xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">
                                    A marketplace where people know each other
                                </h2>
                            </Reveal>

                            <div className="mt-10 grid gap-4 sm:grid-cols-2">
                                {trust.map(({ icon: Icon, title, text }, i) => (
                                    <Reveal key={title} from={i % 2 ? 'right' : 'left'} delay={i * 90}>
                                        <div className="h-full rounded-2xl bg-white/5 p-5 ring-1 ring-white/10 transition duration-300 hover:bg-white/10 hover:ring-sun-400/40">
                                            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-sun-400 text-pine-950">
                                                <Icon size={22} />
                                            </span>
                                            <h3 className="mt-4 font-display text-lg font-bold">{title}</h3>
                                            <p className="mt-1.5 leading-relaxed text-white/75">{text}</p>
                                        </div>
                                    </Reveal>
                                ))}
                            </div>
                        </div>

                        <Reveal from="right" className="relative mx-auto w-full max-w-md lg:mx-0 lg:ml-auto">
                            <SiteImage name={siteImages.community} alt="Students meeting on campus" className="aspect-[4/5] rounded-3xl" />

                            <div className="site-float absolute -bottom-6 left-4 right-4 rounded-2xl bg-white p-5 text-pine-950 shadow-xl sm:-left-8 sm:right-8">
                                <h3 className="font-display text-base font-bold">Meet-up tips</h3>
                                <ul className="mt-2.5 space-y-1.5 text-sm text-pine-900/75">
                                    <li>Meet on campus during the day.</li>
                                    <li>Check the item before you pay.</li>
                                    <li>Keep the conversation in the app.</li>
                                </ul>
                            </div>
                        </Reveal>
                    </div>
                </section>

                {/* Final call to action */}
                {!user && (
                    <section className="bg-white px-5 py-20 sm:px-8 lg:py-28">
                        <Reveal from="up">
                            <div className="site-shimmer relative mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 rounded-3xl bg-sun-400 p-8 sm:p-12 lg:flex-row lg:items-center">
                                <div aria-hidden="true" className="site-drift pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full bg-sun-300/70" />
                                <div className="relative max-w-xl">
                                    <h2 className="font-display text-3xl font-extrabold leading-tight text-pine-950 sm:text-4xl">
                                        Got something you don't use anymore?
                                    </h2>
                                    <p className="mt-3 text-lg leading-relaxed text-pine-950/80">
                                        List it for free and give it a second life with another ACC student.
                                    </p>
                                </div>

                                <div className="relative flex flex-wrap gap-3">
                                    <Link href="/register" className="group inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-pine-900 px-6 font-display text-[15px] font-bold text-white transition hover:bg-pine-950">
                                        Create free account
                                        <ArrowRight size={18} className="transition-transform duration-300 group-hover:translate-x-1" />
                                    </Link>
                                    <Link href="/login" className="inline-flex h-12 items-center justify-center rounded-xl border-2 border-pine-950/40 px-6 font-display text-[15px] font-bold text-pine-950 transition hover:border-pine-950">
                                        Log in
                                    </Link>
                                </div>
                            </div>
                        </Reveal>
                    </section>
                )}
            </main>

            <footer className="bg-pine-950 py-12 text-white/70">
                <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 sm:px-8 md:flex-row md:items-center md:justify-between">
                    <div>
                        <Brand light />
                        <p className="mt-3 max-w-sm text-sm leading-relaxed">The student marketplace of Abuyog Community College.</p>
                    </div>

                    <nav className="flex flex-wrap gap-x-8 gap-y-3 text-sm font-medium" aria-label="Footer">
                        <Link href="/marketplace" className="transition hover:text-white">Marketplace</Link>
                        <Link href="/login" className="transition hover:text-white">Log in</Link>
                        <Link href="/register" className="transition hover:text-white">Create account</Link>
                    </nav>
                </div>

                <p className="mx-auto mt-10 max-w-7xl px-5 text-xs text-white/50 sm:px-8">
                    © {new Date().getFullYear()} ACC Marketplace. All rights reserved.
                </p>
            </footer>
        </div>
    );
}
