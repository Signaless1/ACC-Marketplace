<?php

namespace App\Http\Controllers;

use App\Models\Attachment;
use App\Models\Message;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Serves an uploaded file only to people who are allowed to see it.
 */
class AttachmentController extends Controller
{
    public function show(Request $request, Attachment $attachment): StreamedResponse
    {
        $user = $request->user();
        $owner = $attachment->attachable;

        abort_if($owner === null, 404);

        if ($owner instanceof Message) {
            $conversation = $owner->conversation;

            $isParticipant = $conversation
                && in_array($user->id, [$conversation->buyer_id, $conversation->seller_id], true);

            // Admins may open any file (needed for report dossiers).
            abort_unless($isParticipant || $user->isAdmin(), 403);

            // A message deleted for everyone is only visible to admins.
            abort_if($owner->deleted_for_everyone_at !== null && ! $user->isAdmin(), 404);
        }

        // Review media is public to any signed-in user.

        $disk = Storage::disk($attachment->disk ?? 'public');

        abort_unless($disk->exists($attachment->path), 404);

        $inline = in_array($attachment->kind, ['image', 'video'], true);

        return $disk->response(
            $attachment->path,
            $attachment->original_name,
            ['Content-Type' => $attachment->mime ?: 'application/octet-stream'],
            $inline ? 'inline' : 'attachment'
        );
    }
}
