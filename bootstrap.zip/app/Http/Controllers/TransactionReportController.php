<?php

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Models\Order;
use App\Models\Report;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

/**
 * A compiled, printable record of one transaction, plus a way for the
 * buyer or seller to send it to the admins as a report.
 */
class TransactionReportController extends Controller
{
    public function show(Request $request, Order $order): Response
    {
        $user = $request->user();
        $role = $this->roleFor($user, $order);

        $order->load([
            'listing.category:id,name',
            'buyer:id,name,email,created_at',
            'seller:id,name,email,created_at',
            'reports.reporter:id,name',
        ]);

        $isAdmin = $role === 'admin';

        $openReport = $isAdmin ? null : $order->reports
            ->where('reporter_id', $user->id)
            ->whereIn('status', ['pending', 'reviewing'])
            ->sortByDesc('id')
            ->first();

        return Inertia::render('Orders/TransactionReport', [
            'summary' => $this->summary($order, $isAdmin),
            'reasons' => Report::TRANSACTION_REASONS,
            'viewerRole' => $role,
            'canSubmit' => ! $isAdmin && $openReport === null,
            'openReport' => $openReport ? [
                'id' => $openReport->id,
                'status' => $openReport->status,
                'reason' => $openReport->reason,
                'created_at' => $openReport->created_at,
            ] : null,
        ]);
    }

    public function store(Request $request, Order $order): RedirectResponse
    {
        $user = $request->user();
        $role = $this->roleFor($user, $order);

        abort_if($role === 'admin', 403);

        $validated = $request->validate([
            'reason' => ['required', Rule::in(array_keys(Report::TRANSACTION_REASONS))],
            'description' => ['nullable', 'string', 'max:1000'],
        ]);

        $alreadyOpen = Report::query()
            ->where('reporter_id', $user->id)
            ->where('order_id', $order->id)
            ->whereIn('status', ['pending', 'reviewing'])
            ->exists();

        if ($alreadyOpen) {
            return back()->with('error', 'You have already reported this transaction. Our team is reviewing it.');
        }

        Report::create([
            'reporter_id' => $user->id,
            'order_id' => $order->id,
            'listing_id' => $order->listing_id,
            'reported_user_id' => $role === 'buyer' ? $order->seller_id : $order->buyer_id,
            'reason' => $validated['reason'],
            'description' => $validated['description'] ?? null,
            'status' => 'pending',
        ]);

        return back()->with('success', 'Report sent to the admins. Thank you for helping keep ACC Marketplace safe.');
    }

    /** @return 'buyer'|'seller'|'admin' */
    private function roleFor($user, Order $order): string
    {
        if ($user->isAdmin()) {
            return 'admin';
        }

        abort_unless(in_array($user->id, [$order->buyer_id, $order->seller_id], true), 403);

        return $user->id === $order->buyer_id ? 'buyer' : 'seller';
    }

    private function summary(Order $order, bool $isAdmin): array
    {
        $listing = $order->listing;
        $reference = 'TR-'.str_pad((string) $order->id, 6, '0', STR_PAD_LEFT);
        $unit = (float) $order->price;
        $qty = (int) ($order->quantity ?? 1);

        return [
            'reference' => $reference,
            'generated_at' => now()->toIso8601String(),
            'order' => [
                'id' => $order->id,
                'reference' => '#'.$order->id,
                'status' => $order->status,
                'quantity' => $qty,
                'unit_price' => number_format($unit, 2, '.', ''),
                'total' => number_format($unit * $qty, 2, '.', ''),
                'placed_at' => $order->created_at,
                'cancel_reason' => $order->cancel_reason ?? null,
            ],
            'listing' => $listing ? [
                'id' => $listing->id,
                'title' => $listing->title,
                'category' => $listing->category?->name,
                'type' => $listing->type,
                'condition' => $listing->condition,
                'current_price' => number_format((float) $listing->price, 2, '.', ''),
                'removed' => $listing->hidden_at !== null,
                'removed_reason' => $listing->removed_reason
                    ? (\App\Models\Listing::REMOVAL_REASONS[$listing->removed_reason] ?? $listing->removed_reason)
                    : null,
            ] : null,
            'buyer' => $this->party($order->buyer),
            'seller' => $this->party($order->seller),
            'timeline' => $this->timeline($order),
            'messages' => $this->messages($order, $isAdmin),
            'reports' => $order->reports->sortBy('id')->values()->map(fn (Report $r) => [
                'id' => $r->id,
                'reporter' => $r->reporter?->name,
                'reason' => Report::allReasons()[$r->reason] ?? $r->reason,
                'description' => $r->description,
                'status' => $r->status,
                'filed_at' => $r->created_at,
                'escalated_to' => $r->escalated_to,
                'escalated_at' => $r->escalated_at,
                'admin_note' => $isAdmin ? $r->admin_note : null,
            ])->all(),
        ];
    }

    private function party($user): array
    {
        return [
            'id' => $user?->id,
            'name' => $user?->name ?? 'Deleted user',
            'email' => $user?->email ?? '',
            'member_since' => $user?->created_at,
        ];
    }

    /** Uses the audit trail when present, else falls back to the order's own timestamps. */
    private function timeline(Order $order): array
    {
        $labels = [
            'placed' => 'Order placed',
            'confirmed' => 'Seller confirmed',
            'completed' => 'Marked completed',
            'cancelled' => 'Order cancelled',
        ];

        if (Schema::hasTable('order_events')) {
            $events = DB::table('order_events')
                ->leftJoin('users', 'users.id', '=', 'order_events.user_id')
                ->where('order_events.order_id', $order->id)
                ->orderBy('order_events.created_at')
                ->orderBy('order_events.id')
                ->get(['order_events.event', 'order_events.created_at', 'users.name as by']);

            if ($events->isNotEmpty()) {
                return $events->map(fn ($e) => [
                    'label' => $labels[$e->event] ?? ucfirst($e->event),
                    'at' => $e->created_at,
                    'by' => $e->by,
                    'note' => $e->event === 'cancelled' ? ($order->cancel_reason ?? null) : null,
                ])->all();
            }
        }

        $rows = [['label' => $labels['placed'], 'at' => $order->created_at, 'by' => $order->buyer?->name, 'note' => null]];

        if ($order->confirmed_at) {
            $rows[] = ['label' => $labels['confirmed'], 'at' => $order->confirmed_at, 'by' => $order->seller?->name, 'note' => null];
        }
        if ($order->completed_at) {
            $rows[] = ['label' => $labels['completed'], 'at' => $order->completed_at, 'by' => null, 'note' => null];
        }
        if ($order->cancelled_at) {
            $rows[] = [
                'label' => $labels['cancelled'],
                'at' => $order->cancelled_at,
                'by' => $order->cancelled_by
                    ? ($order->cancelled_by === $order->buyer_id ? $order->buyer?->name : $order->seller?->name)
                    : null,
                'note' => $order->cancel_reason ?? null,
            ];
        }

        return $rows;
    }

    private function messages(Order $order, bool $isAdmin): array
    {
        $conversation = Conversation::query()
            ->where('listing_id', $order->listing_id)
            ->where('buyer_id', $order->buyer_id)
            ->where('seller_id', $order->seller_id)
            ->first();

        if (! $conversation) {
            return [];
        }

        return $conversation->messages()
            ->with(['sender:id,name', 'attachments:id,attachable_id,attachable_type,original_name,kind,size'])
            ->orderBy('id')
            ->get()
            ->map(function ($m) use ($order, $isAdmin) {
                $deleted = $m->deleted_for_everyone_at !== null;
                $hide = $deleted && ! $isAdmin;

                return [
                    'id' => $m->id,
                    'sender' => $m->sender?->name,
                    'role' => $m->sender_id === $order->buyer_id ? 'buyer' : 'seller',
                    'body' => $hide ? null : $m->body,
                    'at' => $m->created_at,
                    'deleted' => $deleted,
                    'attachments' => $hide ? [] : $m->attachments->map(fn ($a) => [
                        'name' => $a->original_name,
                        'kind' => $a->kind,
                        'size' => $this->humanSize((int) $a->size),
                    ])->all(),
                ];
            })->all();
    }

    private function humanSize(int $bytes): string
    {
        return match (true) {
            $bytes >= 1048576 => round($bytes / 1048576, 1).' MB',
            $bytes >= 1024 => round($bytes / 1024).' KB',
            default => $bytes.' B',
        };
    }
}
