<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\Order;
use App\Models\Report;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Tiny JSON endpoint polled by the front end (see resources/js/lib/live.tsx)
 * to keep sidebar badges and the new-message pop-up fresh.
 */
class LiveController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $user = $request->user();
        $userId = $user->id;

        $unread = Message::query()
            ->whereNull('read_at')
            ->whereNull('deleted_for_everyone_at')
            ->where('sender_id', '!=', $userId)
            ->whereHas('conversation', fn ($q) => $q
                ->where('buyer_id', $userId)
                ->orWhere('seller_id', $userId));

        $latest = (clone $unread)
            ->with([
                'sender:id,name',
                'conversation.listing:id,title',
                'attachments:id,attachable_id,attachable_type,kind',
            ])
            ->latest('id')
            ->first();

        return response()->json([
            'unreadMessageCount' => (clone $unread)->count(),
            'latestMessage' => $latest ? [
                'id' => $latest->id,
                'conversation_id' => $latest->conversation_id,
                'sender' => $latest->sender?->name,
                'listing' => $latest->conversation?->listing?->title,
                'preview' => $this->preview($latest),
            ] : null,
            // Orders waiting for this user (as seller) to confirm.
            'pendingOrderCount' => Order::query()
                ->where('seller_id', $userId)
                ->where('status', 'pending')
                ->count(),
            'pendingReportCount' => $user->isAdmin()
                ? Report::where('status', 'pending')->count()
                : 0,
        ]);
    }

    private function preview(Message $message): string
    {
        $body = trim((string) $message->body);

        if ($body !== '') {
            return mb_strimwidth($body, 0, 90, '…');
        }

        return match ($message->attachments->first()?->kind) {
            'image' => 'Sent a photo',
            'video' => 'Sent a video',
            default => 'Sent a file',
        };
    }
}
